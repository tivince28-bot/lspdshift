/* LS Grid — TreeFitty neighborhood map as base (names baked into image).
   No separate label overlays. No Rockstar atlas name layer. */

const W = 1080, H = 1080;
// CRS.Simple: lat = y (0 top → H bottom), lng = x (0 left → W right)
const crs = L.extend({}, L.CRS.Simple, {
  transformation: new L.Transformation(1, 0, 1, 0),
  scale(z){ return Math.pow(2, z - 2); }, // z2 ≈ 1:1 pixels
  zoom(s){ return Math.log(s) / Math.LN2 + 2; }
});

const map = L.map("map", {
  crs,
  center: [780, 540], // Los Santos area on TreeFitty image
  zoom: 3,
  minZoom: 1,
  maxZoom: 6,
  zoomControl: true,
  attributionControl: false,
  maxBounds: [[-40, -40], [H + 40, W + 40]],
  maxBoundsViscosity: 0.8
});

const imageUrl = "treefitty.png";
const imageBounds = [[0, 0], [H, W]];
L.imageOverlay(imageUrl, imageBounds, { opacity: 1, interactive: false }).addTo(map);

const JUMPS = {
  ls:    { lat: 780, lng: 540, z: 3 },
  sandy: { lat: 320, lng: 620, z: 3 },
  paleto:{ lat: 140, lng: 480, z: 3 },
  full:  { lat: 540, lng: 540, z: 1 }
};

const turfLayer = L.layerGroup().addTo(map);
const tagLayer  = L.layerGroup().addTo(map);

/* ---- persistence ---- */
const KEY = "ls-grid-treefitty-v1";
function loadBoard(){
  try { return JSON.parse(localStorage.getItem(KEY)) || { gangs:[], turfs:[], tags:[] }; }
  catch { return { gangs:[], turfs:[], tags:[] }; }
}
function saveBoard(b){ localStorage.setItem(KEY, JSON.stringify(b)); }

let board = loadBoard();
if (!board.gangs.length) {
  board.gangs = [
    { id: "g1", name: "Grove Street Families", color: "#2ecc71" },
    { id: "g2", name: "Ballas", color: "#9b59b6" },
    { id: "g3", name: "Los Santos Vagos", color: "#f1c40f" }
  ];
  saveBoard(board);
}

function activeGangId(){
  return document.getElementById("active-gang").value || (board.gangs[0] && board.gangs[0].id) || null;
}

function renderGangs(){
  const list = document.getElementById("gang-list");
  list.innerHTML = board.gangs.map(g =>
    `<div style="display:flex;align-items:center;gap:8px;margin:4px 0">
      <span style="width:12px;height:12px;border-radius:50%;background:${g.color};flex-shrink:0"></span>
      <span>${g.name}</span>
    </div>`
  ).join("") || "<em>No gangs</em>";

  const sel = document.getElementById("active-gang");
  const cur = sel.value;
  sel.innerHTML = board.gangs.map(g =>
    `<option value="${g.id}">${g.name}</option>`
  ).join("");
  if (cur && board.gangs.some(g => g.id === cur)) sel.value = cur;
}

function renderTurfs(){
  turfLayer.clearLayers();
  board.turfs.forEach(t => {
    const gang = board.gangs.find(g => g.id === t.gangId);
    const color = (gang && gang.color) || "#e74c3c";
    const poly = L.polygon(t.points, {
      color, fillColor: color, fillOpacity: 0.4, weight: 2
    }).addTo(turfLayer);
    poly.on("click", (e) => {
      L.DomEvent.stopPropagation(e);
      document.getElementById("selected").innerHTML =
        `<b>${t.name || "Turf"}</b><br/>Gang: ${gang ? gang.name : "—"}<br/><br/>
         <button style="padding:6px 10px;cursor:pointer" onclick="window._delTurf('${t.id}')">Delete turf</button>`;
    });
  });
}

function renderTags(){
  tagLayer.clearLayers();
  board.tags.forEach(t => {
    const gang = board.gangs.find(g => g.id === t.gangId);
    const color = (gang && gang.color) || "#e74c3c";
    const m = L.circleMarker([t.lat, t.lng], {
      radius: 8, color: "#fff", weight: 2, fillColor: color, fillOpacity: 0.95
    }).addTo(tagLayer);
    m.on("click", (e) => {
      L.DomEvent.stopPropagation(e);
      document.getElementById("selected").innerHTML =
        `<b>${t.name || "Tag"}</b><br/>Gang: ${gang ? gang.name : "—"}<br/><br/>
         <button style="padding:6px 10px;cursor:pointer" onclick="window._delTag('${t.id}')">Delete tag</button>`;
    });
  });
}

window._delTurf = function(id){
  board.turfs = board.turfs.filter(t => t.id !== id);
  saveBoard(board); renderTurfs();
  document.getElementById("selected").textContent = "Turf deleted";
};
window._delTag = function(id){
  board.tags = board.tags.filter(t => t.id !== id);
  saveBoard(board); renderTags();
  document.getElementById("selected").textContent = "Tag deleted";
};

renderGangs();
renderTurfs();
renderTags();

/* ---- UI ---- */
document.getElementById("btn-add-gang").onclick = function(){
  const name = document.getElementById("gang-name").value.trim();
  const color = document.getElementById("gang-color").value;
  if (!name) return;
  board.gangs.push({ id: "g" + Date.now(), name, color });
  saveBoard(board); renderGangs();
  document.getElementById("gang-name").value = "";
};

document.getElementById("jump").onchange = function(){
  const j = JUMPS[this.value];
  if (j) map.setView([j.lat, j.lng], j.z);
};

let mode = "pan"; // pan | draw | tag
let drawPts = [];
let drawGuide = null;

function setMode(m){
  mode = m;
  drawPts = [];
  if (drawGuide) { map.removeLayer(drawGuide); drawGuide = null; }
  document.getElementById("btn-draw").classList.toggle("active", m === "draw");
  document.getElementById("btn-tag").classList.toggle("active", m === "tag");
  document.getElementById("btn-pan").classList.toggle("active", m === "pan");
  const st = document.getElementById("status");
  if (m === "draw") st.textContent = "Click corners · double-click to finish turf";
  else if (m === "tag") st.textContent = "Click the map to place a gang tag";
  else st.textContent = "Neighborhood names are on the map · TreeFitty base";
}

document.getElementById("btn-draw").onclick = () => setMode(mode === "draw" ? "pan" : "draw");
document.getElementById("btn-tag").onclick  = () => setMode(mode === "tag"  ? "pan" : "tag");
document.getElementById("btn-pan").onclick  = () => setMode("pan");

map.on("click", e => {
  if (mode === "tag") {
    board.tags.push({
      id: "t" + Date.now(),
      lat: e.latlng.lat, lng: e.latlng.lng,
      name: "Tag",
      gangId: activeGangId()
    });
    saveBoard(board); renderTags();
    return;
  }
  if (mode === "draw") {
    drawPts.push([e.latlng.lat, e.latlng.lng]);
    if (drawGuide) map.removeLayer(drawGuide);
    drawGuide = L.polyline(drawPts, { color: "#5ec8ff", weight: 2, dashArray: "5 5" }).addTo(map);
  }
});

map.on("dblclick", e => {
  if (mode !== "draw" || drawPts.length < 3) return;
  L.DomEvent.stop(e);
  board.turfs.push({
    id: "p" + Date.now(),
    name: "Territory",
    gangId: activeGangId(),
    points: drawPts.slice()
  });
  saveBoard(board); renderTurfs();
  setMode("pan");
  document.getElementById("status").textContent = "Territory saved";
});

map.on("mousemove", e => {
  if (mode === "pan") {
    document.getElementById("status").textContent =
      `X ${e.latlng.lng.toFixed(0)} · Y ${e.latlng.lat.toFixed(0)} · z${map.getZoom()}`;
  }
});
