import type { Gang, Pin, Territory } from "@/lib/types";

const now = "2026-01-01T00:00:00.000Z";

/** Seed gangs only — turf is drawn by users in tile-pixel map space. */
export const SEED_GANGS: Gang[] = [
  {
    id: "gang-gsf",
    name: "Grove Street Families",
    tag: "GSF",
    color: "#2ecc71",
    status: "active",
    leader: "",
    description: "South LS classic.",
    members: "",
    notes: "",
    logo: "",
    createdAt: now,
    updatedAt: now,
  },
  {
    id: "gang-ballas",
    name: "Ballas",
    tag: "BLS",
    color: "#9b59b6",
    status: "active",
    leader: "",
    description: "Davis / Chamberlain.",
    members: "",
    notes: "",
    logo: "",
    createdAt: now,
    updatedAt: now,
  },
  {
    id: "gang-vagos",
    name: "Los Santos Vagos",
    tag: "VGS",
    color: "#f1c40f",
    status: "active",
    leader: "",
    description: "East side.",
    members: "",
    notes: "",
    logo: "",
    createdAt: now,
    updatedAt: now,
  },
];

export const SEED_TERRITORIES: Territory[] = [];
export const SEED_PINS: Pin[] = [];
