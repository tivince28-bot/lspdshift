/** Map space = TreeFitty neighborhood image pixels (1080×1080). */
export const CRS_A = 1;
export const CRS_B = 0;
export const CRS_C = 1;
export const CRS_D = 0;

export function gameToLatLng(x: number, y: number): { lat: number; lng: number } {
  return { lat: y, lng: x };
}
export function latLngToGame(lat: number, lng: number): { x: number; y: number } {
  return { x: lng, y: lat };
}

export const MAP_CENTER: [number, number] = [780, 540];
export const MAP_DEFAULT_ZOOM = 3;
export const MAP_MIN_ZOOM = 1;
export const MAP_MAX_ZOOM = 6;

export const TILE_STYLES = {
  atlas: {
    url: "/treefitty.png",
    background: "#0b1a2a",
    label: "Neighborhoods",
  },
  satellite: {
    url: "/treefitty.png",
    background: "#0b1a2a",
    label: "Neighborhoods",
  },
  road: {
    url: "/treefitty.png",
    background: "#0b1a2a",
    label: "Neighborhoods",
  },
} as const;

export type TileStyle = keyof typeof TILE_STYLES;

export const MAX_BOUNDS: [[number, number], [number, number]] = [
  [-40, -40],
  [1120, 1120],
];

export const JUMP_TARGETS = [
  { id: "ls", name: "Los Santos", lat: 780, lng: 540, zoom: 3 },
  { id: "sandy", name: "Sandy Shores", lat: 320, lng: 620, zoom: 3 },
  { id: "paleto", name: "Paleto Bay", lat: 140, lng: 480, zoom: 3 },
  { id: "state", name: "San Andreas", lat: 540, lng: 540, zoom: 1 },
] as const;

export const TRANSPARENT_TILE =
  "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";

export const TILE_EXTENT: Record<number, { maxX: number; maxY: number }> = {
  0: { maxX: 0, maxY: 0 },
  1: { maxX: 0, maxY: 1 },
  2: { maxX: 1, maxY: 2 },
  3: { maxX: 3, maxY: 5 },
  4: { maxX: 7, maxY: 11 },
  5: { maxX: 15, maxY: 23 },
  6: { maxX: 31, maxY: 47 },
  7: { maxX: 63, maxY: 95 },
};
