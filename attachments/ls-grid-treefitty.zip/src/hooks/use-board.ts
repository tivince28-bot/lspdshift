import { useCallback, useEffect, useState } from "react";
import { SEED_GANGS, SEED_PINS, SEED_TERRITORIES } from "@/lib/map/seed";
import {
  GANG_STATUSES,
  PIN_KINDS,
  TERRITORY_KINDS,
  type Board,
  type Gang,
  type GangStatus,
  type Pin,
  type PinKind,
  type Territory,
  type TerritoryKind,
} from "@/lib/types";

const KEY = "ls-grid-board-v2";

function stamp() {
  return new Date().toISOString();
}

function isStatus(v: unknown): v is GangStatus {
  return GANG_STATUSES.includes(v as GangStatus);
}
function isKind(v: unknown): v is PinKind {
  return PIN_KINDS.includes(v as PinKind);
}
function isTurfKind(v: unknown): v is TerritoryKind {
  return TERRITORY_KINDS.includes(v as TerritoryKind);
}

function asGang(raw: Partial<Gang> & { id?: string; name?: string }): Gang | null {
  if (!raw.id || !raw.name || !raw.color) return null;
  return {
    id: String(raw.id),
    name: String(raw.name),
    tag: String(raw.tag ?? ""),
    color: String(raw.color),
    status: isStatus(raw.status) ? raw.status : "active",
    leader: String(raw.leader ?? ""),
    description: String(raw.description ?? ""),
    members: String(raw.members ?? ""),
    notes: String(raw.notes ?? ""),
    logo: String(raw.logo ?? ""),
    createdAt: String(raw.createdAt ?? stamp()),
    updatedAt: String(raw.updatedAt ?? stamp()),
  };
}

function asTerritory(raw: Partial<Territory> & { id?: string; name?: string }): Territory | null {
  if (!raw.id || !raw.name || !Array.isArray(raw.polygon) || raw.polygon.length < 3) {
    return null;
  }
  return {
    id: String(raw.id),
    gangId: raw.gangId ? String(raw.gangId) : null,
    name: String(raw.name),
    kind: isTurfKind(raw.kind) ? raw.kind : "turf",
    color: raw.color ? String(raw.color) : null,
    polygon: raw.polygon.map((p) => ({
      lat: Number(p.lat),
      lng: Number(p.lng),
    })),
    notes: String(raw.notes ?? ""),
    createdAt: String(raw.createdAt ?? stamp()),
    updatedAt: String(raw.updatedAt ?? stamp()),
  };
}

function asPin(raw: Partial<Pin> & { id?: string; name?: string }): Pin | null {
  if (!raw.id || !raw.name || typeof raw.lat !== "number" || typeof raw.lng !== "number") {
    if (!raw.id || !raw.name) return null;
    const lat = Number((raw as { lat?: unknown }).lat);
    const lng = Number((raw as { lng?: unknown }).lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
    raw = { ...raw, lat, lng };
  }
  return {
    id: String(raw.id),
    gangId: raw.gangId ? String(raw.gangId) : null,
    name: String(raw.name),
    kind: isKind(raw.kind) ? raw.kind : "graffiti",
    color: raw.color ? String(raw.color) : null,
    lat: Number(raw.lat),
    lng: Number(raw.lng),
    notes: String(raw.notes ?? ""),
    dateFound: String(raw.dateFound ?? "").slice(0, 10),
    image: String(raw.image ?? ""),
    createdAt: String(raw.createdAt ?? stamp()),
    updatedAt: String(raw.updatedAt ?? stamp()),
  };
}

function seedBoard(): Board {
  return {
    gangs: SEED_GANGS,
    territories: SEED_TERRITORIES,
    pins: SEED_PINS,
  };
}

function normalize(raw: unknown): Board {
  const obj = raw as Partial<Board> | null;
  if (!obj || !Array.isArray(obj.gangs)) return seedBoard();
  const gangs = obj.gangs.map(asGang).filter((g): g is Gang => Boolean(g));
  const territories = (obj.territories ?? [])
    .map(asTerritory)
    .filter((t): t is Territory => Boolean(t));
  const pins = (obj.pins ?? []).map(asPin).filter((p): p is Pin => Boolean(p));
  return { gangs, territories, pins };
}

export function useBoard() {
  const [board, setBoard] = useState<Board | null>(null);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      setBoard(raw ? normalize(JSON.parse(raw)) : seedBoard());
    } catch {
      setBoard(seedBoard());
    }
  }, []);

  useEffect(() => {
    if (!board) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(board));
    } catch {
      // quota — ignore
    }
  }, [board]);

  const saveGang = useCallback(async (g: Omit<Gang, "createdAt" | "updatedAt">) => {
    const now = stamp();
    setBoard((b) => {
      if (!b) return b;
      const existing = b.gangs.find((x) => x.id === g.id);
      const next: Gang = existing
        ? { ...existing, ...g, logo: g.logo ?? existing.logo, updatedAt: now }
        : { ...g, logo: g.logo ?? "", createdAt: now, updatedAt: now };
      return {
        ...b,
        gangs: existing
          ? b.gangs.map((x) => (x.id === g.id ? next : x))
          : [...b.gangs, next],
      };
    });
  }, []);

  const saveTerritory = useCallback(
    async (t: Omit<Territory, "createdAt" | "updatedAt">) => {
      const now = stamp();
      setBoard((b) => {
        if (!b) return b;
        const existing = b.territories.find((x) => x.id === t.id);
        const next: Territory = existing
          ? { ...existing, ...t, updatedAt: now }
          : { ...t, createdAt: now, updatedAt: now };
        return {
          ...b,
          territories: existing
            ? b.territories.map((x) => (x.id === t.id ? next : x))
            : [...b.territories, next],
        };
      });
    },
    [],
  );

  const savePin = useCallback(async (p: Omit<Pin, "createdAt" | "updatedAt">) => {
    const now = stamp();
    setBoard((b) => {
      if (!b) return b;
      const existing = b.pins.find((x) => x.id === p.id);
      const next: Pin = existing
        ? {
            ...existing,
            ...p,
            dateFound: p.dateFound ?? existing.dateFound,
            image: p.image ?? existing.image,
            updatedAt: now,
          }
        : {
            ...p,
            dateFound: p.dateFound ?? "",
            image: p.image ?? "",
            createdAt: now,
            updatedAt: now,
          };
      return {
        ...b,
        pins: existing
          ? b.pins.map((x) => (x.id === p.id ? next : x))
          : [...b.pins, next],
      };
    });
  }, []);

  const removeGang = useCallback(async (id: string) => {
    setBoard((b) => {
      if (!b) return b;
      return {
        gangs: b.gangs.filter((g) => g.id !== id),
        territories: b.territories.map((t) =>
          t.gangId === id ? { ...t, gangId: null } : t,
        ),
        pins: b.pins.map((p) => (p.gangId === id ? { ...p, gangId: null } : p)),
      };
    });
  }, []);

  const removeTerritory = useCallback(async (id: string) => {
    setBoard((b) =>
      b ? { ...b, territories: b.territories.filter((t) => t.id !== id) } : b,
    );
  }, []);

  const removePin = useCallback(async (id: string) => {
    setBoard((b) => (b ? { ...b, pins: b.pins.filter((p) => p.id !== id) } : b));
  }, []);

  const replaceBoard = useCallback(async (incoming: Board) => {
    setBoard(normalize(incoming));
  }, []);

  return {
    board,
    gangs: board?.gangs ?? [],
    territories: board?.territories ?? [],
    pins: board?.pins ?? [],
    isLoading: !board,
    saveGang,
    saveTerritory,
    savePin,
    removeGang,
    removeTerritory,
    removePin,
    replaceBoard,
  };
}
