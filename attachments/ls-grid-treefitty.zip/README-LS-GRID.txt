LS Grid — GTA V Los Santos Gang Territory Map
==============================================

This package contains the fixed TreeFitty-based map app.

WHAT CHANGED
- Neighborhood names come from TreeFitty's map image (no floating Labels)
- Labels button / overlay system removed
- Rockstar atlas tiles no longer used for names
- Base map: public/treefitty.png

QUICK START (React app — full UI)
1. Unzip
2. npm install
3. npm run dev
4. Open http://localhost:8080

You should see a green "TREEFITTY · NO LABELS" badge and the
colorful neighborhood map.

SIMPLE STATIC FALLBACK (no npm)
Open ls-map/index.html in a browser, or:
  cd ls-map && python3 -m http.server 8080

FEATURES
- Draw gang territories (polygons)
- Place gang tags
- Create gangs with colors
- Shared data via local DB (PGLite) when using the React app
- Jump to Los Santos / Sandy / Paleto

